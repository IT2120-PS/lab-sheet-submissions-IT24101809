setwd("C:\\Users\\it24101809\\Desktop\\IT24101809")


branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")


boxplot(branch_data$sales, main="Boxplot of Sales", ylab="Sales")


head(branch_data)

boxplot(branch_data$Sales,main="boxplot of sales", ylab="Sales",col="lightblue")

fivenum(branch_data$Advertising)
fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)

find_outliers<-function(x){}
Q1<-quantile(x,0.25)
Q3<-QUANTILE(x,0.75)
iqr<-Q3-Q1

lower<-Q1-1.5*iqr
upper<-Q3+1.5*iqr
outliers<x[x<lower|x>upper]
return(outliers)
